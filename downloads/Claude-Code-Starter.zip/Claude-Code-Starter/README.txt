CLAUDE CODE STARTER
===================

You do not need to know anything. Claude will walk you through it, one small step at a time.

HOW TO START (2 minutes)

1. Open Claude:
   - In a browser: https://claude.ai
   - Or the Claude app: https://claude.ai/download

2. Start a new chat. Drag the file "Claude-Code-Starter.zip" into the message box.

3. Type this and send it:

   Please read this and guide me through getting started. Go one step at a time.

That is all. Claude does the rest.


IF CLAUDE CANNOT OPEN THE ZIP

1. Double-click the zip to open it. You get a folder.
2. Open a new chat. Drag the file "START-HERE.md" from that folder into the message box.
3. Send the same message as above.


WHAT IS IN HERE

- START-HERE.md  The guide that Claude follows. You do not need to read it.
- design-board-template.html  A page for designing your website by clicking. Claude uses it later.
- report-deck-template.html  A report or slide deck you edit by clicking. It downloads as HTML, PDF or PowerPoint.

Keep this zip in your Downloads folder. Claude Code will need to find it later.
